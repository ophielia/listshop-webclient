export class ContactForm {
    constructor(
        public name?: string,
        public phone?: number,
        public email?: string,
        public message?: string,
    ) {}
}