import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-one',
  templateUrl: './intro-one.component.html',
  styleUrls: ['./intro-one.component.scss']
})
export class IntroOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
